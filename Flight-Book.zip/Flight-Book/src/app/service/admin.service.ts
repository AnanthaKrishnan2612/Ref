import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private saveFlightURL = "http://localhost:9393/v1/api/flight/";

  httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        "Access-Control-Allow-Origin": "Content-type"
        })
    };

  public updatedata : any;
  public updateFlag = false;
  constructor(private http: HttpClient) { }

  loginCheck = false;
  saveFlight(data: any) : Observable<any>
  {   

      return this.http.post<any>(this.saveFlightURL+"addflight", data, this.httpOptions); 
  }

  getFlightList(): Observable<any>
  {
    return this.http.get<any>(this.saveFlightURL+"getallflights", this.httpOptions); 
  }

  
  updateFlight(data:any): Observable<any>
  {
    return this.http.put<any>(this.saveFlightURL+"updateflight", data, this.httpOptions); 
  }

  blockFlight(flightid : any): Observable<any>
  {
    return this.http.put(this.saveFlightURL+"blockflight/"+flightid,this.httpOptions); 
  }
  unblockFlight(flightid : any): Observable<any>
  {
    return this.http.put(this.saveFlightURL+"unblockflight/"+flightid,this.httpOptions); 
  }

}
