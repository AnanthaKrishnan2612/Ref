import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BookingTicket } from '../page/bookingTicket';

const CUSTOMER_AUTH_API = 'http://localhost:9090/users/v1/api/users/';
@Injectable({
  providedIn: 'root'
})
export class PassengerserviceService {
   
  
  httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        "Access-Control-Allow-Origin": "*"
        })
    };
  username: any;
  constructor(private http:HttpClient) { }

bookTicket(bookingTicket:BookingTicket) : Observable<any>{
    return this.http.post<any>(CUSTOMER_AUTH_API + "bookticket",{
      bookingTicket}, this.httpOptions);
 }

 getBookingHistory(){
  this.username = sessionStorage.getItem('username');
  return this.http.get<any>(CUSTOMER_AUTH_API+"gettickethistory/"+this.username,this.httpOptions)
 }
  cancelTicket(pnrNumber:any){
    return this.http.put<any>("http://localhost:9091/v1/api/ticket/cancelticket/"+pnrNumber,this.httpOptions)
  }
}
