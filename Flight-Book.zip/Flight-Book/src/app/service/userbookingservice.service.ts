import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const FLIGHT_AUTH_API = 'http://localhost:9090/users/v1/api/users/';


@Injectable({
  providedIn: 'root'
})
export class UserbookingserviceService {
  httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        "Access-Control-Allow-Origin": "*"
        })
    };
   public loginCheck: any;

  constructor(private http:HttpClient) { }

  getFlightList() : Observable<any>{
    return this.http.get<any>("http://localhost:9393/v1/api/flight/getallflights", this.httpOptions);
  }

  getSpecificList(source:any,destination:any,date:any) : Observable<any>{
    return this.http.get<any>(FLIGHT_AUTH_API + "searchflights/"+source+"/"+destination+"/"+date, this.httpOptions);    
  }

  getSingleList(flightNumber:any) : Observable<any>{
    return this.http.get<any>(FLIGHT_AUTH_API+"/getflight/"+flightNumber,this.httpOptions);
  }
 }
