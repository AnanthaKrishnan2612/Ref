import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booknavbar',
  templateUrl: './booknavbar.component.html',
  styleUrls: ['./booknavbar.component.css']
})
export class BooknavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
