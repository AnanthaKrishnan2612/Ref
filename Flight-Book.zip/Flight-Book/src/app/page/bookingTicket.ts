import { PassangerDetails } from "./passangerdetails";
import { TicketDetails } from "./ticketDetails";

export  class BookingTicket{
    public ticketBooked:TicketDetails;
    public passangeList:Array<PassangerDetails>

    constructor( ticketBooked:TicketDetails,
         passangeList:Array<PassangerDetails>){
             this.passangeList=passangeList;
             this.ticketBooked=ticketBooked
         }
}