import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/service/auth-service.service';
import { Router } from '@angular/router';
import { TokenStorageService } from 'src/app/service/token-storage.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  /*form:any = {
    user_name : null,
    password : null
  };*/

 
  isLoggedin = false;
  isLoginFailed = false;
  errorMessage = '';
  roles : string[] = [];
  loginForm:FormGroup;
  constructor(private authService : AuthService,private router: Router,private tokenStorage:TokenStorageService) 
  { this.loginForm = new FormGroup({
    "username": new FormControl("", [
        Validators.required,
        Validators.maxLength(20),
        Validators.minLength(4)
        // Validators.pattern("")
    ]),
    "password":new FormControl("", [Validators.required])
});}

  ngOnInit(): void {
    if (this.tokenStorage.getToken()) {
      this.isLoggedin = true;
      this.roles = this.tokenStorage.getUser().roles;
    }
  }

  
  onSubmit() : void {
    //const { user_name,password } = this.form;
    // this.router.navigate(['/userbooking']);
    if(this.loginForm.value.username=="abhijit@gmail.com" && this.loginForm.value.password=="abhijit@123")
    {
      this.router.navigate(['/admin/addflight']);
    }
    else if(this.loginForm.value.username=="abcd@gmail.com " && this.loginForm.value.password=="user")
    {
      this.router.navigate(['/userbooking']);
      sessionStorage.setItem('username',this.loginForm.value.username);
    }
    else 
    {
      alert("Invalid Credentials")
      const data=console.log("Invalid Credential");
    }
}
 
}
// const data = {
    //   "username" : loginCheck.value.username,
    //   "password" : loginCheck.value.password
    // }
    // sessionStorage.setItem('username',loginCheck.value.username);
    // console.log(loginCheck.value.username);
    // this.authService.login(data).subscribe(
    //   data => {
    //     this.tokenStorage.saveToken(data.accessToken);
    //     this.tokenStorage.saveUser(data);
    //     console.log("Success");
    //     this.isLoginFailed = false;
    //     this.isLoggedin = true;
    //     this.roles = this.tokenStorage.getUser().roles;
      //   this.router.navigate(['/userbooking']);
        
      // },
        
    //   error => {
    //     console.log("ERROR");
    //     console.log(error.error.text);
    //     if(error.error.text=='Success'){
    //       this.router.navigate(['/userbooking']);
    //     } 
    //     this.errorMessage = error.error.message;
    //     this.isLoginFailed = true;
        
    //   }
    // );