export  class PassangerDetails{
    constructor(public passengerId:any,
    public name:any,
    public gender:any,
    public age:any,
    public seatNo:any,
    public isMealReqd:any,
    public  pnrNumber:any){}
}