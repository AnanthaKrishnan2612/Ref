import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookinghistory',
  templateUrl: './bookinghistory.component.html',
  styleUrls: ['./bookinghistory.component.css']
})
export class BookinghistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
