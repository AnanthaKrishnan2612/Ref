import { Component, OnInit } from '@angular/core';
import { UserbookingserviceService } from 'src/app/service/userbookingservice.service';
import { AdminService } from 'src/app/service/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userbooking',
  templateUrl: './userbooking.component.html',
  styleUrls: ['./userbooking.component.css']
})
export class UserbookingComponent implements OnInit {

  flightNumber: any;
  airline: any
  status: any;
  from: any;
  to: any;
  departureDateTime: any;
  returnDateTime: any;
  scheduledDays: any;
  seats: any;
  instrumentsUsed: any;
  totalNoOfRows: any;
  ticketCost: any;
  meals: any;

  user : any;
  source : any;
  destination : any;
  departuretime : any;
  noofseats : any;
  listRecords = false;
  bookingRecords = false;
  headers = [ "Flight Name", "Depature Time", "Arrival Time", "Status","ScheduleDays","Seats","Cost"];
  cityValue = ["Coimbatore", "Chennai","Bangalore","Cochin","Hyderabad","Mumbai","Delhi"];
  flightList : any;
  constructor(private bookingService: UserbookingserviceService,private router:Router) { }

  ngOnInit(): void {
    this.user = this.bookingService.loginCheck;
    this.onLoad();
  }

  onLoad(){
    this.bookingService.getFlightList().subscribe(listdata => {
      this.flightList = listdata;
    });
  }
  onSubmit(searchFlight : any) {    
    console.log(searchFlight.value['source']);
    console.log(searchFlight.value['destination']);
    // alert(searchFlight.value.source);
    // alert(searchFlight.value.destination);
    if(searchFlight.value.from == searchFlight.value.to){
      alert("Both Source and Destination are same Please choose differ");
      return;
    }
    this.source = searchFlight.value.source;
    this.destination = searchFlight.value.destination;
    this.bookingService.getSpecificList(searchFlight.value['from'],searchFlight.value['to'],searchFlight.value['departuretime']).subscribe(listdata => {
       this.flightList = listdata;

       console.log(this.flightList);
    });

    /*this.bookingService.getFlightList(searchFlight).subscribe(listdata => {
      console.log(listdata);*/
      /*listdata.forEach((ele: any) => {         
            temp.push(ele);        
        });
        this.flightList=listdata;
      });
    console.log("Display Add Flight Table = ",this.flightList);
    this.hideManageTable=true;
    console.log("manageFlight Method");*/
    /*});*/
  }

  
  bookTicket(flightNumber: any,ticketCost : any){
    console.log(flightNumber);
    sessionStorage.setItem('flightNumber',this.flightList.flightNumber);
    sessionStorage.setItem('ticketCost',this.flightList.ticketCost);
    this.router.navigate(['/booking/'+flightNumber]);
    

}

}
