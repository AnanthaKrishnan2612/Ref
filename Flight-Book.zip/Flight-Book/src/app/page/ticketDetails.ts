export  class TicketDetails{
   constructor( public eMail:any,
    public  flightNumber:any,
    public departureDateTime: any,
    public returnDateTime: any,
    public   contactNo:any,
    public   noOfSeats: any,
    public  bookingStatus:any,
    public  ticketCost:any,){}
}